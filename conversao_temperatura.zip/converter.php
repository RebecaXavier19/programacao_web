<?php
$c = $_POST["celsius"];
$f = 1.8 * $c + 32;
print "<h1>" . $f . "</h1>";
?>